<?php
require 'koneksi.php';

$response = ['status' => 'error', 'data' => null];

$id = $_GET['id'];
$query = mysqli_query($koneksi, "SELECT * FROM resep WHERE id = '$id'");
if ($query) {
    $jumlah = mysqli_num_rows($query);
    if ($jumlah == 1) {
        $row = mysqli_fetch_object($query);
        $response['status'] = 'success';
        $response['data'] = $row;
    } else {
        $response['message'] = 'Data tidak ditemukan';
    }
} else {
    $response['message'] = 'Gagal mengambil data';
}

http_response_code(200);
echo json_encode($response);
