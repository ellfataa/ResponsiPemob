<?php
require 'koneksi.php';
$input = file_get_contents('php://input');
$data = json_decode($input, true);

$nama_resep = trim($data['nama_resep']);
$langkah = trim($data['langkah']);

$response = ['status' => 'error'];

if ($nama_resep != '' && $langkah != '') {
    $query = mysqli_query($con, "INSERT INTO resep (nama_resep, langkah) VALUES ('$nama_resep', '$langkah')");
    if ($query) {
        $response['status'] = 'success';
        $response['message'] = 'Resep berhasil ditambahkan';
    } else {
        $response['message'] = 'Gagal menambahkan resep';
    }
} else {
    $response['message'] = 'Input tidak lengkap';
}

http_response_code(201);
echo json_encode($response);
