<?php
require 'koneksi.php';

$response = ['status' => 'error', 'data' => [], 'message' => ''];

$query = mysqli_query($con, "SELECT * FROM resep");
if ($query) {
    $data = [];
    while ($row = mysqli_fetch_object($query)) {
        $data[] = $row;
    }
    $response['status'] = 'success';
    $response['data'] = $data;
} else {
    $response['message'] = 'Gagal mengambil data';
}

http_response_code(200);
echo json_encode($response);
