<?php
require 'koneksi.php';
$input = file_get_contents('php://input');
$data = json_decode($input, true);

$id_resep = trim($data['id_resep']);
$nama_resep = trim($data['nama_resep']);
$langkah = trim($data['langkah']);

$response = ['status' => 'error'];

if ($id_resep != '' && $nama_resep != '' && $langkah != '') {
    $query = mysqli_query($con, "UPDATE resep SET nama_resep='$nama_resep', langkah='$langkah' WHERE id='$id_resep'");
    if ($query) {
        $response['status'] = 'success';
        $response['message'] = 'Resep berhasil diperbarui';
    } else {
        $response['message'] = 'Gagal memperbarui resep';
    }
} else {
    $response['message'] = 'Input tidak lengkap';
}

http_response_code(201);
echo json_encode($response);
