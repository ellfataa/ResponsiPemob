<?php
require 'koneksi.php';
$input = file_get_contents('php://input');
$data = json_decode($input, true);

$id_resep = $data['id_resep'];
$response = ['status' => 'error'];

if ($id_resep != '') {
    $query = mysqli_query($con, "DELETE FROM resep WHERE id='$id_resep'");
    if ($query) {
        $response['status'] = 'success';
        $response['message'] = 'Resep berhasil dihapus';
    } else {
        $response['message'] = 'Gagal menghapus resep';
    }
} else {
    $response['message'] = 'ID tidak ditemukan';
}

http_response_code(201);
echo json_encode($response);
